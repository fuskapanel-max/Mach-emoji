package com.afsara.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val voiceReq = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 24)
        }
        val title = TextView(this).apply { text = "Afsara"; textSize = 32f; gravity = 17 }
        status = TextView(this).apply { text = "আমি প্রস্তুত।"; textSize = 18f; gravity = 17 }
        val mic = Button(this).apply { text = "🎙️ Afsara — কথা বলুন"; setOnClickListener { listen() } }
        val google = Button(this).apply { text = "Google খুলুন"; setOnClickListener { openUrl("https://www.google.com") } }
        val youtube = Button(this).apply { text = "YouTube খুলুন"; setOnClickListener { openUrl("https://www.youtube.com") } }
        root.addView(title); root.addView(status); root.addView(mic); root.addView(google); root.addView(youtube)
        setContentView(root)
    }

    private fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Afsara-কে বলুন…")
        }
        startActivityForResult(i, voiceReq)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != voiceReq || resultCode != RESULT_OK) return
        val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.lowercase() ?: return
        status.text = "আপনি বলেছেন: $text"
        when {
            text.contains("google") || text.contains("গুগল") -> openUrl("https://www.google.com")
            text.contains("youtube") || text.contains("ইউটিউব") -> openUrl("https://www.youtube.com")
            text.contains("call") || text.contains("কল") -> status.text = "কলের জন্য Contacts/permission integration পরের ধাপে যোগ হবে।"
            else -> status.text = "কমান্ডটি শোনা হয়েছে।"
        }
    }

    private fun openUrl(url: String) {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }
}
